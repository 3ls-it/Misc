" Detect TI-89 BASIC source
augroup ftdetect_ti89
  autocmd!
  autocmd BufNewFile,BufRead *.ti89 setfiletype ti89
augroup END

