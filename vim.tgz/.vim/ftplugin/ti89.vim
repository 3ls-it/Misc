" Reasonable defaults for TI-89 BASIC text
setlocal expandtab
setlocal shiftwidth=4
setlocal tabstop=4
setlocal softtabstop=4

" TI-89 BASIC (ASCII source, pretty rendering via conceal)
" Show concealed characters (2 = show a placeholder for concealed text; 0/1 also possible)
setlocal conceallevel=2

" What to use when something is fully concealed (listchars can interact; pick what you like)
setlocal concealcursor=nc

" Commentstring for your convention (works with some plugins/mappings)
setlocal commentstring=(c)\ %s

